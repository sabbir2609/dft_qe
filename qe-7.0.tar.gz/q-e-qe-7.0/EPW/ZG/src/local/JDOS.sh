#!/bin/bash
path_to_qe/EPW/ZG_displacement/src/local/JDOS_Gaus.x < JDOS_Gaus.in > JDOS_Gaus.out 
