!
! Copyright (C) 2003-2013 Quantum ESPRESSO group
! This file is distributed under the terms of the
! GNU General Public License. See the file `License'
! in the root directory of the present distribution,
! or http://www.gnu.org/copyleft/gpl.txt .
!
   include 'laxlib_low.fh'
   include 'laxlib_mid.fh'
   include 'laxlib_hi.fh'
   include 'laxlib_param.fh'

   INTEGER, EXTERNAL ::  ldim_block, ldim_cyclic, ldim_block_sca
